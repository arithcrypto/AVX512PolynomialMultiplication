/**
 * \file gf2x.c
 * \brief AVX2 implementation of multiplication of two polynomials
 */

#include "gf2x.h"
#include "parameters.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <immintrin.h>


#define VEC_N_ARRAY_SIZE_VEC CEIL_DIVIDE(PARAM_N_MULT, 256) /*!< The number of needed vectors to store PARAM_N bits*/
#define WORD 64
#define LAST64 (PARAM_N >> 6)

#define T_3W 2048
#define T_3W_256 (T_3W>>8)
#define T2_3W_256 (2*T_3W_256)
#define TREC_3W 6144
#define TREC_3W_256 (TREC_3W>>8)
#define T2REC_3W_256 (2*TREC_3W_256)

uint64_t a1_times_a2[VEC_N_256_SIZE_64 << 1];
uint64_t tmp_reduce[VEC_N_ARRAY_SIZE_VEC << 2];
__m256i *o256 = (__m256i *) tmp_reduce;
uint64_t bloc64[PARAM_OMEGA_R]; // Allocation with the biggest possible weight
uint64_t bit64[PARAM_OMEGA_R]; // Allocation with the biggest possible weight

static inline void reduce(uint64_t *o, uint64_t *a);
inline static void karat_mult_1(__m128i *C, __m128i *A, __m128i *B);
inline static void karat_mult_2(__m256i *C, __m256i *A, __m256i *B);
inline static void karat_mult_4(__m256i *C, __m256i *A, __m256i *B);
inline static void karat_mult_8(__m256i *C, __m256i *A, __m256i *B);
inline static void karat_three_way_mult(__m256i *C, __m256i *A, __m256i *B);
inline static void karat_mult9(uint64_t *C, const uint64_t *A, const uint64_t *B);


/**
 * @brief Compute o(x) = a(x) mod \f$ X^n - 1\f$
 *
 * This function computes the modular reduction of the polynomial a(x)
 *
 * @param[out] o Pointer to the result
 * @param[in] a Pointer to the polynomial a(x)
 */
static inline void reduce(uint64_t *o, uint64_t *a) {
	__m256i r256, carry256;
	__m256i *a256 = (__m256i *) a;
	static const int32_t dec64 = PARAM_N & 0x3f;
	static const int32_t d0 = WORD - dec64;
	int32_t i, i2;

	for (i = LAST64 ; i < (PARAM_N >> 5) - 4 ; i += 4) {
		r256 = _mm256_lddqu_si256((__m256i const *) (& a[i]));
		r256 = _mm256_srli_epi64(r256, dec64);
		carry256 = _mm256_lddqu_si256((__m256i const *) (& a[i + 1]));
		carry256 = _mm256_slli_epi64(carry256, d0);
		r256 ^= carry256;
		i2 = (i - LAST64) >> 2;
		o256[i2] = a256[i2] ^ r256;
	}

	i = i - LAST64;

	for (; i < LAST64 + 1 ; i++) {
		uint64_t r = a[i + LAST64] >> dec64;
		uint64_t carry = a[i + LAST64 + 1] << d0;
		r ^= carry;
		tmp_reduce[i] = a[i] ^ r;
	}

	tmp_reduce[LAST64] &= RED_MASK;
	memcpy(o, tmp_reduce, VEC_N_SIZE_BYTES);
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 * A(x) and B(x) are stored in 128-bit registers
 * This function computes A(x)*B(x) using Karatsuba
 *
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
inline static void karat_mult_1(__m128i *C, __m128i *A, __m128i *B) {
	__m128i D1[2];
	__m128i D0[2], D2[2];
	__m128i Al = _mm_loadu_si128(A);
	__m128i Ah = _mm_loadu_si128(A + 1);
	__m128i Bl = _mm_loadu_si128(B);
	__m128i Bh = _mm_loadu_si128(B + 1);

	//	Compute Al.Bl=D0
	__m128i DD0 = _mm_clmulepi64_si128(Al, Bl, 0);
	__m128i DD2 = _mm_clmulepi64_si128(Al, Bl, 0x11);
	__m128i AAlpAAh = _mm_xor_si128(Al, _mm_shuffle_epi32(Al, 0x4e));
	__m128i BBlpBBh = _mm_xor_si128(Bl, _mm_shuffle_epi32(Bl, 0x4e));
	__m128i DD1 = _mm_xor_si128(_mm_xor_si128(DD0, DD2), _mm_clmulepi64_si128(AAlpAAh, BBlpBBh, 0));
	D0[0] = _mm_xor_si128(DD0, _mm_unpacklo_epi64(_mm_setzero_si128(), DD1));
	D0[1] = _mm_xor_si128(DD2, _mm_unpackhi_epi64(DD1, _mm_setzero_si128()));

	//	Compute Ah.Bh=D2
	DD0 = _mm_clmulepi64_si128(Ah, Bh, 0);
	DD2 = _mm_clmulepi64_si128(Ah, Bh, 0x11);
	AAlpAAh = _mm_xor_si128(Ah, _mm_shuffle_epi32(Ah, 0x4e));
	BBlpBBh = _mm_xor_si128(Bh, _mm_shuffle_epi32(Bh, 0x4e));
	DD1 = _mm_xor_si128(_mm_xor_si128(DD0, DD2), _mm_clmulepi64_si128(AAlpAAh, BBlpBBh, 0));
	D2[0] = _mm_xor_si128(DD0, _mm_unpacklo_epi64(_mm_setzero_si128(), DD1));
	D2[1] = _mm_xor_si128(DD2, _mm_unpackhi_epi64(DD1, _mm_setzero_si128()));

	// Compute AlpAh.BlpBh=D1
	// Initialisation of AlpAh and BlpBh
	__m128i AlpAh = _mm_xor_si128(Al,Ah);
	__m128i BlpBh = _mm_xor_si128(Bl,Bh);
	DD0 = _mm_clmulepi64_si128(AlpAh, BlpBh, 0);
	DD2 = _mm_clmulepi64_si128(AlpAh, BlpBh, 0x11);
	AAlpAAh = _mm_xor_si128(AlpAh, _mm_shuffle_epi32(AlpAh, 0x4e));
	BBlpBBh = _mm_xor_si128(BlpBh, _mm_shuffle_epi32(BlpBh, 0x4e));
	DD1 = _mm_xor_si128(_mm_xor_si128(DD0, DD2), _mm_clmulepi64_si128(AAlpAAh, BBlpBBh, 0));
	D1[0] = _mm_xor_si128(DD0, _mm_unpacklo_epi64(_mm_setzero_si128(), DD1));
	D1[1] = _mm_xor_si128(DD2, _mm_unpackhi_epi64(DD1, _mm_setzero_si128()));

	// Final comutation of C
	__m128i middle = _mm_xor_si128(D0[1], D2[0]);
	C[0] = D0[0];
	C[1] = middle ^ D0[0] ^ D1[0];
	C[2] = middle ^ D1[1] ^ D2[1];
	C[3] = D2[1];
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 *
 * This function computes A(x)*B(x) using Karatsuba
 * A(x) and B(x) are stored in 256-bit registers
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
inline static void karat_mult_2(__m256i *C, __m256i *A, __m256i *B) {
	__m256i D0[2], D1[2], D2[2], SAA, SBB;
	__m128i *A128 = (__m128i *)A, *B128 = (__m128i *)B;

	karat_mult_1((__m128i *) D0, A128, B128);
	karat_mult_1((__m128i *) D2, A128 + 2, B128 + 2);

	SAA = _mm256_xor_si256(A[0], A[1]);
	SBB = _mm256_xor_si256(B[0], B[1]);

	karat_mult_1((__m128i *) D1,(__m128i *) &SAA,(__m128i *) &SBB);
	__m256i middle = _mm256_xor_si256(D0[1], D2[0]);

	C[0] = D0[0];
	C[1] = middle ^ D0[0] ^ D1[0];
	C[2] = middle ^ D1[1] ^ D2[1];
	C[3] = D2[1];
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 *
 * This function computes A(x)*B(x) using Karatsuba
 * A(x) and B(x) are stored in 256-bit registers
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
inline static void karat_mult_4(__m256i *C, __m256i *A, __m256i *B) {
	__m256i D0[4], D1[4], D2[4], SAA[2], SBB[2];

	karat_mult_2(D0, A, B);
	karat_mult_2(D2, A + 2, B + 2);

	SAA[0] = A[0] ^ A[2];
	SBB[0] = B[0] ^ B[2];
	SAA[1] = A[1] ^ A[3];
	SBB[1] = B[1] ^ B[3];

	karat_mult_2( D1, SAA, SBB);

	__m256i middle0 = _mm256_xor_si256(D0[2], D2[0]);
	__m256i middle1 = _mm256_xor_si256(D0[3], D2[1]);

	C[0] = D0[0];
	C[1] = D0[1];
	C[2] = middle0 ^ D0[0] ^ D1[0];
	C[3] = middle1 ^ D0[1] ^ D1[1];
	C[4] = middle0 ^ D1[2] ^ D2[2];
	C[5] = middle1 ^ D1[3] ^ D2[3];
	C[6] = D2[2];
	C[7] = D2[3];
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 *
 * This function computes A(x)*B(x) using Karatsuba
 * A(x) and B(x) are stored in 256-bit registers
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
inline static void karat_mult_8(__m256i *C, __m256i *A, __m256i *B) {
	__m256i D0[8], D1[8], D2[8], SAA[4], SBB[4];

	karat_mult_4(D0, A, B);
	karat_mult_4(D2, A + 4, B + 4);

	for (int32_t i = 0 ; i < 4 ; i++) {
		int32_t is = i + 4;
		SAA[i] = A[i] ^ A[is];
		SBB[i] = B[i] ^ B[is];
	}

	karat_mult_4(D1, SAA, SBB);

	for (int32_t i = 0 ; i < 4 ; i++) {
		int32_t is = i + 4;
		int32_t is2 = is + 4;
		int32_t is3 = is2 + 4;

		__m256i middle = _mm256_xor_si256(D0[is], D2[i]);

		C[i]   = D0[i];
		C[is]  = middle ^ D0[i] ^ D1[i];
		C[is2] = middle ^ D1[is] ^ D2[is];
		C[is3] = D2[is];
	}
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 *
 * This function computes A(x)*B(x) using Karatsuba 3 part split
 * A(x) and B(x) are stored in 256-bit registers
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
inline static void karat_three_way_mult(__m256i *Out, __m256i *A, __m256i *B) {
	__m256i *a0, *b0, *a1, *b1, *a2, *b2;
	__m256i aa01[T_3W_256], bb01[T_3W_256], aa02[T_3W_256], bb02[T_3W_256], aa12[T_3W_256], bb12[T_3W_256];
	__m256i D0[T2_3W_256], D1[T2_3W_256], D2[T2_3W_256], D3[T2_3W_256], D4[T2_3W_256], D5[T2_3W_256];
	__m256i ro256[3 * T2_3W_256];

	a0 = A;
	a1 = A + T_3W_256;
	a2 = A + (T_3W_256 << 1);

	b0 = B;
	b1 = B + T_3W_256;
	b2 = B + (T_3W_256 << 1);

	for (int32_t i = 0 ; i < T_3W_256 ; i++) {
		aa01[i] = a0[i] ^ a1[i];
		bb01[i] = b0[i] ^ b1[i];

		aa12[i] = a2[i] ^ a1[i];
		bb12[i] = b2[i] ^ b1[i];

		aa02[i] = a0[i] ^ a2[i];
		bb02[i] = b0[i] ^ b2[i];
	}

	karat_mult_8(D0, a0, b0);
	karat_mult_8(D1, a1, b1);
	karat_mult_8(D2, a2, b2);

	karat_mult_8(D3, aa01, bb01);
	karat_mult_8(D4, aa02, bb02);
	karat_mult_8(D5, aa12, bb12);

	for (int32_t i = 0 ; i < T_3W_256 ; i++) {
		int32_t j = i + T_3W_256;
		__m256i middle0 = D0[i] ^ D1[i] ^ D0[j];
		ro256[i] = D0[i];
		ro256[j]  = D3[i] ^ middle0;
		ro256[j + T_3W_256] = D4[i] ^ D2[i] ^ D3[j] ^ D1[j] ^ middle0;
		middle0 = D1[j] ^ D2[i] ^ D2[j];
		ro256[j + (T_3W_256 << 1)] = D5[i] ^ D4[j] ^ D0[j] ^ D1[i] ^ middle0;
		ro256[i + (T_3W_256 << 2)] = D5[j] ^ middle0;
		ro256[j + (T_3W_256 << 2)] = D2[j];
	}

	for (int32_t i = 0 ; i < T2REC_3W_256 ; i++) {
		Out[i] = ro256[i];
	}
}



/**
 * @brief Compute C(x) = A(x)*B(x)
 *
 * This function computes A(x)*B(x) using Karatsuba 3 part split
 * A(x) and B(x) are stored in 256-bit registers
 * @param[out] C Pointer to the result
 * @param[in] A Pointer to the polynomial A(x)
 * @param[in] B Pointer to the polynomial B(x)
 */
static inline void karat_mult9(uint64_t *Out, const uint64_t *A, const uint64_t *B) {
	__m256i *A256 = (__m256i *)A, *B256 = (__m256i *)B,*C = (__m256i *)Out;
	__m256i *a0, *b0, *a1, *b1, *a2, *b2;
	__m256i aa01[TREC_3W_256], bb01[TREC_3W_256], aa02[TREC_3W_256], bb02[TREC_3W_256], aa12[TREC_3W_256], bb12[TREC_3W_256];
	__m256i D0[T2REC_3W_256], D1[T2REC_3W_256], D2[T2REC_3W_256], D3[T2REC_3W_256], D4[T2REC_3W_256], D5[T2REC_3W_256];

	a0 = A256;
	a1 = A256+TREC_3W_256;
	a2 = A256+(T2REC_3W_256);

	b0 = B256;
	b1 = B256+TREC_3W_256;
	b2 = B256+(T2REC_3W_256);

	for (int32_t i = 0 ; i < TREC_3W_256 ; i++) {
		aa01[i] = a0[i] ^ a1[i];
		bb01[i] = b0[i] ^ b1[i];

		aa12[i] = a2[i] ^ a1[i];
		bb12[i] = b2[i] ^ b1[i];

		aa02[i] = a0[i] ^ a2[i];
		bb02[i] = b0[i] ^ b2[i];
	}

	karat_three_way_mult(D0, a0, b0);
	karat_three_way_mult(D1, a1, b1);
	karat_three_way_mult(D2, a2, b2);

	karat_three_way_mult(D3, aa01, bb01);
	karat_three_way_mult(D4, aa02, bb02);
	karat_three_way_mult(D5, aa12, bb12);

	for (int32_t i = 0 ; i < TREC_3W_256 ; i++) {
		int32_t j = i + TREC_3W_256;
		__m256i middle0 = D0[i] ^ D1[i] ^ D0[j];
		C[i] = D0[i];
		C[j]  = D3[i] ^ middle0;
		C[j + TREC_3W_256] = D4[i] ^ D2[i] ^ D3[j] ^ D1[j] ^ middle0;
		middle0 = D1[j] ^ D2[i] ^ D2[j];
		C[j + (TREC_3W_256 << 1)] = D5[i] ^ D4[j] ^ D0[j] ^ D1[i] ^ middle0;
		C[i + (TREC_3W_256 << 2)] = D5[j] ^ middle0;
		C[j + (TREC_3W_256 << 2)] = D2[j];
	}
}



/**
 * @brief Multiply two polynomials modulo \f$ X^n - 1\f$.
 *
 * This functions multiplies a dense polynomial <b>a1</b> (of Hamming weight equal to <b>weight</b>)
 * and a dense polynomial <b>a2</b>. The multiplication is done modulo \f$ X^n - 1\f$.
 *
 * @param[out] o Pointer to the result
 * @param[in] a1 Pointer to a polynomial
 * @param[in] a2 Pointer to a polynomial
 */
void vect_mul(uint64_t *o, const uint64_t *a1, const uint64_t *a2) {
	karat_mult9(a1_times_a2, a1, a2);
	reduce(o, a1_times_a2);

	// clear all
	#ifdef __STDC_LIB_EXT1__
		memset_s(a1_times_a2, 0, (VEC_N_SIZE_64 << 1) * sizeof(uint64_t));
	#else
		memset(a1_times_a2, 0, (VEC_N_SIZE_64 << 1) * sizeof(uint64_t));
	#endif
}
